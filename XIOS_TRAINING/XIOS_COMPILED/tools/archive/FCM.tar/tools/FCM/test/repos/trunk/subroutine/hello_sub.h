WRITE (*, '(A)') this // ': ' // TRIM (hello_string)
