#!/usr/bin/ksh
# Calls : hello.exe
# Calls : plot.pro

hello.exe
